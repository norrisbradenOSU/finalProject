﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NorrisCollectionLab
{
    public partial class Form1 : Form
    {
        private const int MaxElements = 17;
        private const int MinValue = -1217;
        private const int MaxValue = 1217;

        private List<int> collection = new List<int>();

        public Form1()
        {
            InitializeComponent();
        }

        private void addToCollectionButton_Click(object sender, EventArgs e)
        {
            string input = enterNumTextBox.Text;

            try
            {
                int number = ValidateNumber(input);
                AddNumberToCollection(number);
                enterNumTextBox.Clear();
            }
            catch (Exception ex)
            {
                statsBox.Text = ex.Message;
                enterNumTextBox.Clear();
            }
        }

        private void showStatsButton_Click(object sender, EventArgs e)
        {
            if (collection.Count == 0)
            {
                statsBox.Text = "Collection is empty.";
                return;
            }

            collectionDisplay.Text = string.Join(Environment.NewLine, collection);

            double average = CalculateAverage();
            int highestNumber = CalculateHighestNumber();
            int lowestNumber = CalculateLowestNumber();

            string statsMessage = $"Average: {average:F4}" +
                $"{Environment.NewLine}Highest Number: {highestNumber}" +
                $"{Environment.NewLine}Lowest Number: {lowestNumber}" +
                $"{Environment.NewLine}Number of Numbers: {collection.Count}";

            statsBox.Text = statsMessage;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            collection.Clear();
            collectionDisplay.Text = "";
            statsBox.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Reset()
        {
            collection.Clear();
            collectionDisplay.Text = "";
            statsBox.Text = "Collection has been cleared.";
        }

        private int ValidateNumber(string input)
        {
            if (!int.TryParse(input, out int number))
            {
                throw new Exception("Invalid input. Please enter an integer.");
            }

            if (number < MinValue || number > MaxValue)
            {
                throw new Exception("Value out of range error. Please enter a number between -1,217 and 1,217.");
            }

            return number;
        }


            private void AddNumberToCollection(int number)
            {
                if (collection.Count >= MaxElements)
                {
                    throw new Exception("Collection full error. Only 17 numbers are allowed.");
                }

                collection.Add(number);
                collectionDisplay.Text = string.Join(Environment.NewLine, collection);
            }
        

        private double CalculateAverage()
        {
            int sum = 0;

            foreach (int number in collection)
            {
                sum += number;
            }

            return (double)sum / collection.Count;
        }

        private int CalculateHighestNumber()
        {
            int highest = collection[0];

            foreach (int number in collection)
            {
                if (number > highest)
                {
                    highest = number;
                }
            }

            return highest;
        }

        private int CalculateLowestNumber()
        {
            int lowest = collection[0];

            foreach (int number in collection)
            {
                if (number < lowest)
                {
                    lowest = number;
                }
            }

            return lowest;
        }

    }
}
